character(female1).
character(female2).
character(female3).

left(female1).
middle(female2).
right(female3).

dress(yellow).
dress(white).
dress(checked).

wearsADress(female1, yellow).
wearsADress(female2, white).
wearsADress(female3, checked).