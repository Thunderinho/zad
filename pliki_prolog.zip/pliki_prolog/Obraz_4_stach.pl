character(szarik).
character(gustlik).
character(janek).
character(roman).
character(grigorij).

title(czterejPancerniIPies).

dog(szarik).
male(gustlik; janek; roman; grigorij).

helmetGreen(gustlik; janek; roman).
helmetGray(grigorij).




