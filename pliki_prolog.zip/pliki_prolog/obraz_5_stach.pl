character(Hawkeye).
character(cpt.america).
character(BlackWidow).

female(BlackWidow).
male(cpt.america; Hawkeye).

weapons(gun).
weapons(bow).
weapons(shield).

holdsAWeapon(cpt.america, shield).
holdsAWeapon(Hawkeye, bow).
holdsAWeapon(BlackWidow, gun).
